#ifndef MYL_H
#define MYL_H

#define OK 1
#define ERR 0

int printStr(char *);
int printInt(int);
int readInt(int *);
int readFlt(float *);
int printFlt(float);

#endif
